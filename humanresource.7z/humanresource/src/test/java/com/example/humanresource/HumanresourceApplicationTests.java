package com.example.humanresource;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HumanresourceApplicationTests {

	@Test
	void contextLoads() {
	}

}
